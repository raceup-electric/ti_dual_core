#ifndef GPIO_MANAGEMENT_H_
#define GPIO_MANAGEMENT_H_

void GPIOSetup();

#endif
